<?php 
$Receive_email="yrf45@gmail.com";
$redirect="https://www.google.com/";
?>